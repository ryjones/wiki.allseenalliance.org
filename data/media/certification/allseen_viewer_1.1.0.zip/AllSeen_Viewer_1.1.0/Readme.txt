*****************************************************************
* _______________________AllSeen Viewer_________________________*
*  Version: 1.1.0                                               *  
*  Developed for AllSeen Alliance by: AT4 wireless S.A.         *
*****************************************************************

 DESCRIPTION
------------------------------------------------------------------------------------------------------------------
 AllSeen Viewer presents AllSeen Self-Certification Tool logcat output in a easily readable, and organized manner.

 SYSTEM REQUIREMENTS
------------------------------------------------------------------------------------------------------------------
 - Windows XP or superior.
 - Microsoft .NET Framework 4.5 or superior.
 
 IMPORTANT NOTE (!)
------------------------------------------------------------------------------------------------------------------
 Do not delete "AllSeen_TestCases.txt" file nor move it because AllSeen Viewer relies on it to find correct
 Test Cases' names and description. This information is included in "AllSeen_TestCases.txt" file according to 
 AllJoyn Services specifications.
 
 PACKAGE CONTENT
------------------------------------------------------------------------------------------------------------------
 AllSeen Viewer is and standalone executable. Thus, this package does not need to be installed in Windows. 
 
 Package content is listed below:
  - AllSeenViewer.exe
  - AllSeen_TestCases.txt
  - Logcat_Samples
	 - AT4_test_2014-09-03_#01
	 - AT4_test_2014-09-03_#02
	 - AT4_test_2014-09-03_#03
	 - AT4_test_2014-09-03_#04
	 
 FEATURES
------------------------------------------------------------------------------------------------------------------
 - Show Self-Certification Tool logcat output.
 - Show aggregated results based on active Self-Certification Tool logcat output.
 - Export active Self-Certification Tool logcat output to CSV format.
 - Open multiple Self-Certification Tool logcat outputs.
 
 USAGE INSTRUCTIONS PER FEATURE
------------------------------------------------------------------------------------------------------------------
 - Show Self-Certification Tool logcat output.
 Once AllSeen Viewer is open you can open a Self-Certification Tool logcat file by clicking on "Open Log"
 button. Self-Certification Tool logcat files must be in plain text format (*.txt).
 
 - Show aggregated results based on active Self-Certification Tool logcat output.
 Log file statistics table of the selected file is shown in window's top.
 File path of the selected file is shown in window's bottom.
 
 - Export active Self-Certification Tool logcat output to CSV format.
 You can export selected log output to CSV format by clicking on "Export to CSV" button located in window's top.
 To read more about CSV format go to the following link: http://en.wikipedia.org/wiki/Comma-separated_values
 
 - Open multiple Self-Certification Tool logcat outputs.
 To switch between logcat outputs you have to click in the corresponding tab. In order to close a logcat just click 
 on the close button inside the tab that corresponds to the file you want to delete.
 
 HOW TO ADD MORE TEST CASES DEFINITIONS
------------------------------------------------------------------------------------------------------------------
 In order to add new test cases definitions edit "AllSeen_TestCases.txt" file. 
 
 File format is as following: 
  - TestCaseName;Description
 Example: 
  - Audio-v1-17;Playing an empty AudioSink remains IDLE
  
 Note that there is only a Test Case definition per line.

CHANGELOG
------------------------------------------------------------------------------------------------------------------
 1.0   
 - Initial release.
 1.0.1 
 - Fixed a problem where logcat files with incomplete information caused an error. 
	Now valid information is shown.
 1.0.2
 - Added support for test cases of Lighting Service according to its specifications.
 - Improved handling of incomplete logcat files. 
	Now if Device ID or App ID cannot be found the "Unknown" message is shown in the aggregated results.
 1.1.0
 - Added support for test cases of Gateway Service according to its specifications.
 - Added support for a new test case of Core according to Core specifications.
 - Improved failure cause field in table entries. 
	Now you can read an extended error information just clicking on a button.
 - Improved handling of erroneous logcat files.
	Now a test case that starts but doesn't end has an inconclusive status and it is reflected with a question icon.
	
